"""Backward compatibility layer."""

from .compatibility import CompatibilityLayer

__all__ = ["CompatibilityLayer"]